#include "Astar_searcher.h"

using namespace std;
using namespace Eigen;

GridNodePtr curentNode_ = NULL;

// 分辨率 下界（m） 上界（m） 3d_[id]
void AstarPathFinder::initGridMap(double _resolution, Vector3d global_xyz_l, Vector3d global_xyz_u, int max_x_id, int max_y_id, int max_z_id)
{   
    gl_xl = global_xyz_l(0);
    gl_yl = global_xyz_l(1);
    gl_zl = global_xyz_l(2);

    gl_xu = global_xyz_u(0);
    gl_yu = global_xyz_u(1);
    gl_zu = global_xyz_u(2);
    
    GLX_SIZE = max_x_id;
    GLY_SIZE = max_y_id;
    GLZ_SIZE = max_z_id;
    GLYZ_SIZE  = GLY_SIZE * GLZ_SIZE;
    GLXYZ_SIZE = GLX_SIZE * GLYZ_SIZE;

    resolution = _resolution;
    inv_resolution = 1.0 / _resolution;    

    data = new uint8_t[GLXYZ_SIZE];
    memset(data, 0, GLXYZ_SIZE * sizeof(uint8_t));
    
    GridNodeMap = new GridNodePtr ** [GLX_SIZE];
    for(int i = 0; i < GLX_SIZE; i++){
        GridNodeMap[i] = new GridNodePtr * [GLY_SIZE];
        for(int j = 0; j < GLY_SIZE; j++){
            GridNodeMap[i][j] = new GridNodePtr [GLZ_SIZE];
            for( int k = 0; k < GLZ_SIZE;k++){
                Vector3i tmpIdx(i,j,k);
                Vector3d pos = gridIndex2coord(tmpIdx);
                GridNodeMap[i][j][k] = new GridNode(tmpIdx, pos);
            }
        }
    }
}

void AstarPathFinder::resetGrid(GridNodePtr ptr)
{
    ptr->id = 0;
    ptr->cameFrom = NULL;
    ptr->gScore = inf;
    ptr->fScore = inf;
}

void AstarPathFinder::resetUsedGrids()
{   
    for(int i=0; i < GLX_SIZE ; i++)
        for(int j=0; j < GLY_SIZE ; j++)
            for(int k=0; k < GLZ_SIZE ; k++)
                resetGrid(GridNodeMap[i][j][k]);
}

void AstarPathFinder::setObs(const double coord_x, const double coord_y, const double coord_z)
{
    if( coord_x < gl_xl  || coord_y < gl_yl  || coord_z <  gl_zl || 
        coord_x >= gl_xu || coord_y >= gl_yu || coord_z >= gl_zu )
        return;

    int idx_x = static_cast<int>( (coord_x - gl_xl) * inv_resolution);
    int idx_y = static_cast<int>( (coord_y - gl_yl) * inv_resolution);
    int idx_z = static_cast<int>( (coord_z - gl_zl) * inv_resolution);      

    data[idx_x * GLYZ_SIZE + idx_y * GLZ_SIZE + idx_z] = 1;
}

vector<Vector3d> AstarPathFinder::getVisitedNodes()
{   
    vector<Vector3d> visited_nodes;
    for(int i = 0; i < GLX_SIZE; i++)
        for(int j = 0; j < GLY_SIZE; j++)
            for(int k = 0; k < GLZ_SIZE; k++){   
                //if(GridNodeMap[i][j][k]->id != 0) // visualize all nodes in open and close list
                if(GridNodeMap[i][j][k]->id == -1)  // visualize nodes in close list only
                    visited_nodes.push_back(GridNodeMap[i][j][k]->coord);
            }

    ROS_WARN("visited_nodes size : %d", visited_nodes.size());
    return visited_nodes;
}

Vector3d AstarPathFinder::gridIndex2coord(const Vector3i & index) 
{
    Vector3d pt;

    pt(0) = ((double)index(0) + 0.5) * resolution + gl_xl;
    pt(1) = ((double)index(1) + 0.5) * resolution + gl_yl;
    pt(2) = ((double)index(2) + 0.5) * resolution + gl_zl;

    return pt;
}

Vector3i AstarPathFinder::coord2gridIndex(const Vector3d & pt) 
{
    Vector3i idx;
    idx <<  min( max( int( (pt(0) - gl_xl) * inv_resolution), 0), GLX_SIZE - 1),
            min( max( int( (pt(1) - gl_yl) * inv_resolution), 0), GLY_SIZE - 1),
            min( max( int( (pt(2) - gl_zl) * inv_resolution), 0), GLZ_SIZE - 1);                  
  
    return idx;
}

Eigen::Vector3d AstarPathFinder::coordRounding(const Eigen::Vector3d & coord)
{
    return gridIndex2coord(coord2gridIndex(coord));
}

inline bool AstarPathFinder::isOccupied(const Eigen::Vector3i & index) const
{
    return isOccupied(index(0), index(1), index(2));
}

inline bool AstarPathFinder::isFree(const Eigen::Vector3i & index) const
{
    return isFree(index(0), index(1), index(2));
}

inline bool AstarPathFinder::isOccupied(const int & idx_x, const int & idx_y, const int & idx_z) const 
{
    return  (idx_x >= 0 && idx_x < GLX_SIZE && idx_y >= 0 && idx_y < GLY_SIZE && idx_z >= 0 && idx_z < GLZ_SIZE && 
            (data[idx_x * GLYZ_SIZE + idx_y * GLZ_SIZE + idx_z] == 1));
}

inline bool AstarPathFinder::isFree(const int & idx_x, const int & idx_y, const int & idx_z) const 
{
    return (idx_x >= 0 && idx_x < GLX_SIZE && idx_y >= 0 && idx_y < GLY_SIZE && idx_z >= 0 && idx_z < GLZ_SIZE && 
           (data[idx_x * GLYZ_SIZE + idx_y * GLZ_SIZE + idx_z] < 1));
}

inline void AstarPathFinder::AstarGetSucc(GridNodePtr currentPtr, vector<GridNodePtr> & neighborPtrSets, vector<double> & edgeCostSets)
{   
    neighborPtrSets.clear();
    edgeCostSets.clear();

    //expand all neighbors
    for(int dx=-1;dx<=1;dx++)
    for(int dy=-1;dy<=1;dy++)
        for(int dz=-1;dz<=1;dz++){
        auto dir = Vector3i(dx,dy,dz);
        auto id = currentPtr->index+dir;
        if(isFree(id)){
            if(0==dx&&0==dy&&0==dz)continue;
            neighborPtrSets.push_back(GridNodeMap[id(0)][id(1)][id(2)]);
            edgeCostSets.push_back(dir.cast<double>().norm());
        }; 
        }
}

double AstarPathFinder::getHeu(GridNodePtr node1, GridNodePtr node2)
{
    /* 
    choose possible heuristic function you want
    Manhattan, Euclidean, Diagonal, or 0 (Dijkstra)
    Remember tie_breaker learned in lecture, add it here ?
    */

    // return 0;  //dijstra    
    // return (node1->index-node2->index).cast<double>().norm(); // Euclidean l2norm
    // return (node1->index-node2->index).lpNorm<1>(); // Manhattan l1norm
    // return (node1->index-node2->index).lpNorm<Eigen::Infinity>();  // inf norm

    auto dir = (node1->index-node2->index).cwiseAbs();
    std::vector<int> dir_v={dir(0),dir(1),dir(2)};
    std::sort(dir_v.begin(),dir_v.end(),std::greater<int>());
    return dir_v[0]+(sqrt(2)-1)*dir_v[1]+(sqrt(3)-sqrt(2))*dir_v[2];  //Diagonal

    // auto dir = (node1->index-node2->index).cwiseAbs();
    // return dir.sum()+(sqrt(3)-3)*dir.minCoeff();  // class Diagonal

    //l2norm + tie breaker 
    //1. more big
    // return (node1->index-node2->index).cast<double>().norm()*(1+1e-10); 
    //2. cross
    // if(curentNode_==NULL)curentNode_ = node1;
    // auto b = (node2->index-node1->index).cast<double>();
    // auto a = (node2->index-curentNode_->index).cast<double>();
    // auto cross = std::abs(a.dot(b)-a.norm()*b.norm());
    // return b.norm() + cross*0.001;
}

void AstarPathFinder::AstarGraphSearch(Vector3d start_pt, Vector3d end_pt)
{   
    ROS_INFO("[AstarPathFinder::AstarGraphSearch]:A-star Search, start(%f,%f,%f),goal(%f,%f,%f)",start_pt(0),start_pt(1),start_pt(2),end_pt(0),end_pt(1),end_pt(2));
    ros::Time time_1 = ros::Time::now();    

    //index of start_point and end_point
    startIdx = coord2gridIndex(start_pt);
    goalIdx   = coord2gridIndex(end_pt);

    //Initialize the pointers of struct GridNode which represent start node and goal node
    GridNodePtr startPtr = GridNodeMap[startIdx(0)][startIdx(1)][startIdx(2)];
    GridNodePtr endPtr   = GridNodeMap[goalIdx(0)][goalIdx(1)][goalIdx(2)];

    //openSet is the open_list implemented through multimap in STL library
    openSet.clear();
    // currentPtr represents the node with lowest f(n) in the open_list
    GridNodePtr currentPtr  = NULL;
    GridNodePtr neighborPtr = NULL;

    //0. put start node in open set
    startPtr -> gScore = 0;
    startPtr -> fScore = getHeu(startPtr,endPtr);   
    startPtr -> id = 1; 
    startPtr -> coord = start_pt;
    openSet.insert( make_pair(startPtr -> fScore, startPtr) );

    vector<GridNodePtr> neighborPtrSets;
    vector<double> edgeCostSets;
    while ( !openSet.empty() ){
        currentPtr = openSet.begin()->second;
        curentNode_ = currentPtr;
        // finish: if the current node is the goal 
        if( currentPtr->index == goalIdx ){
            ros::Time time_2 = ros::Time::now();
            terminatePtr = currentPtr;
            ROS_WARN("[A*]{sucess}  Time in A*  is %f ms, path cost if %f m", (time_2 - time_1).toSec() * 1000.0, currentPtr->gScore * resolution );            
            return;
        }

        //1. remove lowest cost node, and add to close set
        currentPtr->id = -1;
        openSet.erase(openSet.begin()); 

        //2. expand all neibors of currentNode
        AstarGetSucc(currentPtr, neighborPtrSets, edgeCostSets);

        //3. address all neighbors      
        for(int i = 0; i < (int)neighborPtrSets.size(); i++){
           neighborPtr = neighborPtrSets[i];
            if(neighborPtr -> id == 0){ //case 1: discover a new node，add to open set
               neighborPtr -> id =  1;
               neighborPtr->cameFrom = currentPtr;
               neighborPtr->gScore = currentPtr->gScore+edgeCostSets[i];
               neighborPtr->fScore = neighborPtr->gScore+getHeu(neighborPtr,endPtr);
               openSet.insert(make_pair(neighborPtr->fScore,neighborPtr));
                continue;
            }
            else if(neighborPtr -> id == 1){ //case 2: update open set
                auto gScore = currentPtr->gScore+edgeCostSets[i];
                if(gScore < neighborPtr->gScore){  //update neighbor in open-set
                    auto items = openSet.equal_range(neighborPtr->fScore);                    
                    decltype(openSet)::iterator it;
                    for(it=items.first;it!=items.second;it++){
                        if(it->second->index==neighborPtr->index){
                            break;
                        }
                    }
                    neighborPtr->cameFrom = currentPtr;
                    neighborPtr->gScore = gScore;
                    neighborPtr->fScore = neighborPtr->gScore+getHeu(currentPtr,endPtr); //还需要重新排序吗？？？？？
                    openSet.erase(it);
                    openSet.insert(make_pair(neighborPtr->fScore,neighborPtr));
                    continue;
                }
            }
            else{
                continue; //case 3: this node is in closed set, nothing
            }
        }      
    }
    //if search fails
    ros::Time time_2 = ros::Time::now();
    if((time_2 - time_1).toSec() > 0.1)
        ROS_WARN("Time consume in Astar path finding is %f", (time_2 - time_1).toSec() );
}

vector<Vector3d> AstarPathFinder::getPath() 
{   
    vector<Vector3d> path;
    vector<GridNodePtr> gridPath;

    for(auto &trail = terminatePtr; trail != NULL; trail=trail->cameFrom){
        gridPath.emplace_back(trail);
    }

    for (auto ptr: gridPath)
        path.push_back(ptr->coord);
        
    reverse(path.begin(),path.end());

    return path;
}